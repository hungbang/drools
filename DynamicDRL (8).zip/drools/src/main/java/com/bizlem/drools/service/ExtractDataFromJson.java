package com.bizlem.drools.service;

public interface ExtractDataFromJson {
  void extractRulesAndVariableInfo(String inputJson);
}
