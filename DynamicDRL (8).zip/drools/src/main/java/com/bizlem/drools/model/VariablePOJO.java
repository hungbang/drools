package com.bizlem.drools.model; 
import lombok.Data;
import lombok.NoArgsConstructor;
@Data 
@NoArgsConstructor 
public class VariablePOJO 
 { 
private String account_Name; 
private String output1; 
private String output2; 
private String output_field_name_3; 
private String  account_BillingCountry; 
private String output_field_name_4; 
private String output_field_name_1; 
private String output_field_name_2; 
private String  contact_Name; 
private String  contact_Email; 
private String account_Type; 
private String test_Variable; 
private Integer  account_AnnualRevenue; 
private String case_Subject; 
private Integer  case_CaseNumber; 
private String account_BillingCity; 

}