package com.bizlem.drools.service;

import com.bizlem.drools.model.VariablePOJO;

public interface RuleCallingService {

  VariablePOJO callRules(String drlName, VariablePOJO variablePOJO);

}
